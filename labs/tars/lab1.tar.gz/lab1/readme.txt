Please let us know about any problems, unclear instructions and whether some parts take too much time.

There is likely to appear ".DS_STORE" files in my archives sometimes. Just delete them. OSX puts it in without letting me see it.


/Ingemar
